﻿using System.Data;

namespace BusinessLayer.DB.Interfaces
{
    public interface IFunctions
    {
        bool AddRecords();
        bool DeleteRecords();
        DataSet GetRecords();
        DataSet UpdateRecords();
    }
}