﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using BusinessLayer.DB.Interfaces;

namespace BusinessLayer.DB
{
    public class Functions : DBConnection, IFunctions
    {
        public bool AddRecords()
        {
            if (ConnString().Length > 0)
            {
                return true;
            }

            return false;
        }

        public DataSet GetRecords()
        {
            return new DataSet();
        }
        
        public DataSet UpdateRecords()
        {
            return new DataSet();
        }

        public bool DeleteRecords()
        {
            return true;
        }
    }
}
