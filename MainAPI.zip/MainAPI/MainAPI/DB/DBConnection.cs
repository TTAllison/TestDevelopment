﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace BusinessLayer.DB
{
    public class DBConnection
    {
        public string ConnString()
        { 
            string connString = "";
            try
            {
                return connString = ConfigurationManager.ConnectionStrings["MainConnectionString"].ConnectionString;
            }
            catch (Exception ex)
            {
                return connString;
            }
        }
    }
}
