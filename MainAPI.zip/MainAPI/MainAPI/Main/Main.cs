﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Main
{
    public static class Main
    {
        public static string IsOnline()
        {
            return "Hello World";
        }

        public static string ConnString()
        {
            DB.Functions fun = new DB.Functions();
            return fun.ConnString();
        }
    }
}
