﻿namespace ModelAPI.Interfaces
{
    public interface IMainModel
    {
        string Message { get; set; }
    }
}