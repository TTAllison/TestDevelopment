﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using MainAPI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MainAPI.Tests
{
    [TestClass()]
    public class MainServiceTests
    {
        [TestMethod()]
        public void IsOnlineTest()
        {
            MainService ms = new MainService();

            string str = ms.IsOnline();
            Assert.IsTrue(str.Length > 0, "Hellow World value was not returned");

            str = ms.ConnString();
            Assert.IsTrue(str.Length > 0, "connString value was not returned");

            //Assert.Fail();
        }
    }
}