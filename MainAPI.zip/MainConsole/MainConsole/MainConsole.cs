﻿using BusinessLayer.Main;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MainConsole
{
    class MainConsole
    {
        static void Main(string[] args)
        {
            MainAPI.MainService svr = new MainAPI.MainService();

            string str = svr.IsOnline();
            Console.WriteLine(str);
            str = svr.ConnString();
            Console.WriteLine(str);
            Console.ReadKey();
            Console.WriteLine("One ");
            Console.ReadKey();

        }
    }
}
